package com.example.aplicacion

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.SpannableString
import android.text.style.UnderlineSpan
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class juego : AppCompatActivity() {

    private lateinit var wordTextView: TextView
    private lateinit var letterInput: TextView
    private lateinit var guessButton: Button

    private lateinit var hangmanImageView: ImageView
    private lateinit var hangmanImageView2: ImageView
    private lateinit var hangmanImageView3: ImageView
    private lateinit var hangmanImageView4: ImageView
    private lateinit var hangmanImageView5: ImageView

    private var numErrors: Int = 0

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        wordTextView = findViewById(R.id.wordTextView)
        letterInput = findViewById(R.id.letterInput)
        guessButton = findViewById(R.id.guessButton)

        hangmanImageView = findViewById(R.id.hangmanImageView)
        hangmanImageView2 = findViewById(R.id.hangmanImageView2)
        hangmanImageView3 = findViewById(R.id.hangmanImageView3)
        hangmanImageView4 = findViewById(R.id.hangmanImageView4)
        hangmanImageView5 = findViewById(R.id.hangmanImageView5)

        // Ocultar todas las imágenes del ahorcado al inicio
        hangmanImageView.visibility = View.GONE
        hangmanImageView2.visibility = View.GONE
        hangmanImageView3.visibility = View.GONE
        hangmanImageView4.visibility = View.GONE
        hangmanImageView5.visibility = View.GONE

        guessButton.setOnClickListener {
            val guessedCorrectly = checkLetterGuess()

            if (!guessedCorrectly) {
                showNextBodyPart()
            }
        }
    }

    private fun checkLetterGuess(): Boolean {
        val guessedLetter = letterInput.text.toString().toUpperCase()

        val word = "AHORCADO"
        val guessedCorrectly = word.contains(guessedLetter)

        val spannableString = SpannableString(word)
        for (i in word.indices) {
            if (word[i].toString().equals(guessedLetter, ignoreCase = true)) {
                spannableString.setSpan(UnderlineSpan(), i, i + 1, 0)
            }
        }
        wordTextView.text = spannableString

        return guessedCorrectly
    }

    private fun showNextBodyPart() {
        numErrors++

        when (numErrors) {
            1 -> hangmanImageView.visibility = View.VISIBLE
            2 -> hangmanImageView2.visibility = View.VISIBLE
            3 -> hangmanImageView3.visibility = View.VISIBLE
            4 -> hangmanImageView4.visibility = View.VISIBLE
            5 -> hangmanImageView5.visibility = View.VISIBLE
        }
    }
}